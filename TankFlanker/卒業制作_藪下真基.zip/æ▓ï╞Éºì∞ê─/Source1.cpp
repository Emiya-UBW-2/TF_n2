
VECTOR_ref�@VECTOR�̃��b�p�[

	VECTOR_ref tmp;//0,0,0�ŏ�����
	tmp = VGet(0, 0, 0);//VECTOR�����ł���
	tmp += VGet(0, 0, 0);//VECTOR�ł� tmp = VAdd(tmp.get(),VGet(0,0,0));�Ɠ���
	tmp + tmp//VAdd(tmp.get(),tmp.get())�Ɠ������ʂ��o��
	tmp -= VGet(0, 0, 0);//tmp = VSub(tmp.get(),VGet(0,0,0));�Ɠ���
	tmp - tmp//VSub(tmp.get(),tmp.get())�Ɠ������ʂ��o��
	tmp *= 2.f;//tmp = VScalw(tmp.get(),2.f);�Ɠ���
	tmp * 2.f//VScalw(tmp.get(),2.f)�Ɠ������ʂ��o��
	tmp /= 2.f;//tmp = VScalw(tmp.get(),1.f/2.f);�Ɠ���
	tmp / 2.f//VScalw(tmp.get(),1.f/2.f)�Ɠ������ʂ��o��
	tmp.cross(tmp2)//�O�σx�N�g���𓾂�
	tmp.dot(tmp2)//���ς̑傫���𓾂�
	tmp.Norm()//�傫����1.f�ɐ�����
	tmp.clear()//0,0,0�Ƀ��Z�b�g
	tmp.size()//�傫���𓾂�
	tmp.get()//VECTOR���Q�Ƃ���
	rmp.x()//x�������Q��
	rmp.y()//y�������Q��
	rmp.z()//z�������Q��
	rmp.x(10.f)//x�������w��
	rmp.y(10.f)//y�������w��
	rmp.z(10.f)//z�������w��
	rmp.xadd(10.f)//x�����ɉ��Z
	rmp.yadd(10.f)//y�����ɉ��Z
	rmp.zadd(10.f)//z�����ɉ��Z
	//�J�v�Z���ƎO�p�`�Ƃ̓����蔻��
	static bool Hit_Capsule_Tri(const VECTOR_ref& startpos, const VECTOR_ref& endpos, float size, const VECTOR_ref& tri_p1, const VECTOR_ref& tri_p2, const VECTOR_ref& tri_p3);
	//�����Ɠ_�̍ŋߓ_
	static float Segment_Point_MinLen(const VECTOR_ref& startpos, const VECTOR_ref& endpos, const VECTOR_ref& tgt);
//
MATRIX_ref�@MATRIX�̃��b�p�[

	MATRIX_ref tmp;//DxLib::MGetIdent()�ŏ�����
	tmp += tmp;//VECTOR�ł� tmp = MAdd�Ɠ���
	tmp + tmp//MAdd�Ɠ������ʂ��o��
	tmp *= 2.f;//MMult
	tmp * 2.f//MMult
	tmp.Scale(2.f)//�X�P�[�����O
	tmp.size()//�傫���𓾂�
	tmp.clear()//DxLib::MGetIdent()�Ƀ��Z�b�g
	tmp.get()//MATRIX���Q�Ƃ���
	static MATRIX_ref Axis1(const VECTOR_ref& xvec, const VECTOR_ref& yvec, const VECTOR_ref& zvec) noexcept { return { DxLib::MGetAxis1(xvec.get(),yvec.get(),zvec.get(),VGet(0,0,0)) }; }
	static MATRIX_ref Axis1(const VECTOR_ref& xvec, const VECTOR_ref& yvec, const VECTOR_ref& zvec, const VECTOR_ref& pos) noexcept { return { DxLib::MGetAxis1(xvec.get(),yvec.get(),zvec.get(),pos.get()) }; }
	static MATRIX_ref Axis2(const VECTOR_ref& xvec, const VECTOR_ref& yvec, const VECTOR_ref& zvec) noexcept { return { DxLib::MGetAxis2(xvec.get(),yvec.get(),zvec.get(),VGet(0,0,0)) }; }
	static MATRIX_ref Axis2(const VECTOR_ref& xvec, const VECTOR_ref& yvec, const VECTOR_ref& zvec, const VECTOR_ref& pos) noexcept { return { DxLib::MGetAxis2(xvec.get(),yvec.get(),zvec.get(),pos.get()) }; }
	static MATRIX_ref RotX(const float& rad) noexcept { return { DxLib::MGetRotX(rad) }; }
	static MATRIX_ref RotY(const float& rad) noexcept { return { DxLib::MGetRotY(rad) }; }
	static MATRIX_ref RotZ(const float& rad) noexcept { return { DxLib::MGetRotZ(rad) }; }
	static MATRIX_ref RotAxis(const VECTOR_ref& p1, const float& p2) { return DxLib::MGetRotAxis(p1.get(), p2); }
	static MATRIX_ref RotVec2(const VECTOR_ref& p1, const VECTOR_ref& p2) noexcept { return { DxLib::MGetRotVec2(p1.get(), p2.get()) }; }
	static MATRIX_ref Scale(const VECTOR_ref& scale) noexcept { return { DxLib::MGetScale(scale.get()) }; }
	static MATRIX_ref Mtrans(const VECTOR_ref& p1) { return DxLib::MGetTranslate(p1.get()); }
	static VECTOR_ref Vtrans(const VECTOR_ref& p1, const MATRIX_ref& p2) { return DxLib::VTransform(p1.get(), p2.get()); }
	tmp.pos()//���W���Q��
	tmp.xvec()//x�������Q��
	tmp.yvec()//y�������Q��
	tmp.zvec()//z�������Q��

class SoundHandle {
private:
	int handle_;
	constexpr SoundHandle(int h) noexcept : handle_(h) {}
	static constexpr int invalid_handle = -1;
public:
	constexpr SoundHandle() noexcept : handle_(invalid_handle) {}
	SoundHandle(const SoundHandle&) = delete;
	SoundHandle(SoundHandle&& o) noexcept : handle_(o.handle_) {
		o.handle_ = invalid_handle;
	}
	SoundHandle& operator=(const SoundHandle&) = delete;
	SoundHandle& operator=(SoundHandle&& o) noexcept {
		this->handle_ = o.handle_;
		o.handle_ = invalid_handle;
		return *this;
	}
	~SoundHandle() noexcept {
		if (-1 != this->handle_) {
			DeleteSoundMem(this->handle_);
		}
	}
	void Dispose() noexcept {
		if (-1 != this->handle_) {
			DeleteSoundMem(this->handle_);
			this->handle_ = -1;
		}
	}
	int get() const noexcept { return handle_; }
	SoundHandle Duplicate() const noexcept { return DxLib::DuplicateSoundMem(this->handle_); }
	bool play(const int& type, const int& flag = 1) const noexcept { return (PlaySoundMem(handle_, type, flag) == 0); }
	bool stop() const noexcept { return (StopSoundMem(handle_) == 0); }
	bool vol(const int& vol) const noexcept { return (ChangeVolumeSoundMem(std::clamp<int>(vol, 0, 255), handle_) == 0); }
	bool SetPosition(const VECTOR_ref& pos) const noexcept { return (Set3DPositionSoundMem(pos.get(), handle_) == 0); }
	bool Radius(const float& radius) const noexcept { return (Set3DRadiusSoundMem(radius, handle_) == 0); }
	void play_3D(const VECTOR_ref& pos, const float& radius) {
		SetPosition(pos);
		Radius(radius);
		play(DX_PLAYTYPE_BACK, TRUE);
	}
	static SoundHandle Load(std::basic_string_view<TCHAR> FileName, const int& BufferNum = 3) noexcept {
		return { DxLib::LoadSoundMemWithStrLen(FileName.data(), FileName.length(), BufferNum) };
	}
};
class GraphHandle {
private:
	int handle_;
	constexpr GraphHandle(int h) noexcept : handle_(h) {}
	static constexpr int invalid_handle = -1;

public:
	constexpr GraphHandle(void) noexcept : handle_(invalid_handle) {}
	GraphHandle(const GraphHandle&) = delete;
	GraphHandle(GraphHandle&& o) noexcept : handle_(o.handle_) {
		o.handle_ = invalid_handle;
	}
	GraphHandle& operator=(const GraphHandle&) = delete;
	GraphHandle& operator=(GraphHandle&& o) noexcept {
		this->handle_ = o.handle_;
		o.handle_ = invalid_handle;
		return *this;
	}

	void operator=(int& hand) noexcept {
		this->handle_ = hand;
		return;
	}

	~GraphHandle(void) noexcept {
		if (this->handle_ != -1) { DeleteGraph(this->handle_); }
	}
	void Dispose(void) noexcept {
		if (this->handle_ != -1) {
			DeleteGraph(this->handle_);
			this->handle_ = -1;
		}
	}
	int get(void) const noexcept { return handle_; }

	GraphHandle Duplicate(void) const noexcept { return this->handle_; }

	static GraphHandle Load(std::basic_string_view<TCHAR> FileName, bool NotUse3DFlag = false) noexcept {
		return { DxLib::LoadGraphWithStrLen(FileName.data(), FileName.length(), NotUse3DFlag) };
	}
	static GraphHandle LoadDiv(std::basic_string_view<TCHAR> FileName, const int& AllNum, const int& XNum, const int& YNum, const int& XSize, const int& YSize, int *HandleArray, bool NotUse3DFlag = false) noexcept {
		return { DxLib::LoadDivGraphWithStrLen(FileName.data(), FileName.length(), AllNum, XNum, YNum,   XSize, YSize, HandleArray, NotUse3DFlag) };
	}

	static GraphHandle Make(const int& SizeX, const int& SizeY, bool trns = false) noexcept {
		return { DxLib::MakeScreen(SizeX, SizeY, (trns ? TRUE : FALSE)) };
	}

	void DrawGraph(const int& posx, const int& posy, bool trns) noexcept {
		if (this->handle_ != -1) {
			DxLib::DrawGraph(posx, posy, this->handle_, (trns ? TRUE : FALSE));
		}
	}

	void DrawRotaGraph(const int& posx, const int& posy, float Exrate, float rad, bool trns) noexcept {
		if (this->handle_ != -1) {
			DxLib::DrawRotaGraph(posx, posy, double(Exrate), double(rad), this->handle_, (trns ? TRUE : FALSE));
		}
	}

	void DrawExtendGraph(const int& posx1, const int& posy1, const int& posx2, const int& posy2, bool trns) noexcept {
		if (this->handle_ != -1) {
			DxLib::DrawExtendGraph(posx1, posy1, posx2, posy2, this->handle_, (trns ? TRUE : FALSE));
		}
	}
	//GetGraphSize
	void GetSize(int*xsize, int*ysize) noexcept {
		if (this->handle_ != -1) {
			GetGraphSize(this->handle_, xsize, ysize);
		}
	}
	//
	void SetDraw_Screen(const bool& clear = true) {
		SetDrawScreen(this->handle_);
		if (clear) {
			ClearDrawScreen();
		}
	}
	/*
	void SetDraw_Screen(const cam_info& cams) {
		SetDraw_Screen(true);
		SetCameraNearFar(cams.near_, cams.far_);
		SetupCamera_Perspective(cams.fov);
		SetCameraPositionAndTargetAndUpVec(cams.campos.get(), cams.camvec.get(), cams.camup.get());
	}
	*/
	void SetDraw_Screen(const VECTOR_ref& campos, const VECTOR_ref& camvec, const VECTOR_ref& camup, const float& fov, const float& near_, const float& far_) {
		SetDraw_Screen(true);
		SetCameraNearFar(near_, far_);
		SetupCamera_Perspective(fov);
		SetCameraPositionAndTargetAndUpVec(campos.get(), camvec.get(), camup.get());
	}
	//
	static void SetDraw_Screen(const int& handle, const bool& clear = true) {
		SetDrawScreen(handle);
		if (clear) {
			ClearDrawScreen();
		}
	}
	static void SetDraw_Screen(const int& handle, const VECTOR_ref& campos, const VECTOR_ref& camvec, const VECTOR_ref& camup, const float& fov, const float& near_, const float& far_) {
		SetDraw_Screen(handle);
		SetCameraNearFar(near_, far_);
		SetupCamera_Perspective(fov);
		SetCameraPositionAndTargetAndUpVec(campos.get(), camvec.get(), camup.get());
	}
};
class FontHandle {
private:
	int handle_;
	constexpr FontHandle(int h) noexcept : handle_(h) {}
	static constexpr int invalid_handle = -1;

public:
	constexpr FontHandle(void) noexcept : handle_(invalid_handle) {}
	FontHandle(const FontHandle&) = delete;
	FontHandle(FontHandle&& o) noexcept : handle_(o.handle_) {
		o.handle_ = invalid_handle;
	}
	FontHandle& operator=(const FontHandle&) = delete;
	FontHandle& operator=(FontHandle&& o) noexcept {
		this->handle_ = o.handle_;
		o.handle_ = invalid_handle;
		return *this;
	}
	~FontHandle(void) noexcept {
		if (-1 != this->handle_) {
			DeleteFontToHandle(this->handle_);
		}
	}
	void Dispose(void) noexcept {
		if (-1 != this->handle_) {
			DeleteFontToHandle(this->handle_);
			this->handle_ = -1;
		}
	}
	int get(void) const noexcept { return handle_; }
	bool DrawString(const int& x, const int& y, std::basic_string_view<TCHAR> String, unsigned int Color, unsigned int EdgeColor = 0, bool VerticalFlag = false) const noexcept {
		return DxLib::DrawNStringToHandle(x, y, String.data(), String.size(), Color, this->handle_, EdgeColor, VerticalFlag) == TRUE;
	}

	template <typename... Args>
	bool DrawStringFormat(const int& x, const int& y, unsigned int Color, std::string String, Args&&... args) const noexcept {
		return DxLib::DrawFormatStringToHandle(x, y, Color, this->handle_, String.c_str(), args...) == TRUE;
	}


	int GetDrawWidth(std::basic_string_view<TCHAR> String, bool VerticalFlag = false) const noexcept {
		return DxLib::GetDrawNStringWidthToHandle(String.data(), String.size(), this->handle_, VerticalFlag);
	}

	template <typename... Args>
	int GetDrawWidthFormat(std::string String, Args&&... args) const noexcept {
		return DxLib::GetDrawFormatStringWidthToHandle(this->handle_, String.c_str(), args...);
	}
	//�E���瑵��
	bool DrawString_RIGHT(const int& x, const int& y, std::basic_string_view<TCHAR> String, unsigned int Color, unsigned int EdgeColor = 0, bool VerticalFlag = false) const noexcept {
		return DxLib::DrawNStringToHandle(x - GetDrawWidth(String), y, String.data(), String.size(), Color, this->handle_, EdgeColor, VerticalFlag) == TRUE;
	}
	template <typename... Args>
	bool DrawStringFormat_RIGHT(const int& x, const int& y, unsigned int Color, std::string String, Args&&... args) const noexcept {
		return DxLib::DrawFormatStringToHandle(x - GetDrawWidthFormat(String.c_str(), args...), y, Color, this->handle_, String.c_str(), args...) == TRUE;
	}
	//��������
	bool DrawString_MID(const int& x, const int& y, std::basic_string_view<TCHAR> String, unsigned int Color, unsigned int EdgeColor = 0, bool VerticalFlag = false) const noexcept {
		return DxLib::DrawNStringToHandle(x - GetDrawWidth(String) / 2, y, String.data(), String.size(), Color, this->handle_, EdgeColor, VerticalFlag) == TRUE;
	}
	template <typename... Args>
	bool DrawStringFormat_MID(const int& x, const int& y, unsigned int Color, std::string String, Args&&... args) const noexcept {
		return DxLib::DrawFormatStringToHandle(x - GetDrawWidthFormat(String.c_str(), args...) / 2, y, Color, this->handle_, String.c_str(), args...) == TRUE;
	}

	static FontHandle Create(std::basic_string_view<TCHAR> FontName, const int& Size, const int& FontType = -1, const int& CharSet = -1, const int& EdgeSize = -1, bool Italic = false) noexcept {
		return { DxLib::CreateFontToHandleWithStrLen(FontName.data(), FontName.length(), Size, Size / 3, FontType, CharSet, EdgeSize, Italic) };
	}
	static FontHandle Create(const int& Size, const int& FontType = -1, const int& CharSet = -1, const int& EdgeSize = -1, bool Italic = false) noexcept {
		return { DxLib::CreateFontToHandle(nullptr, Size, Size / 3, FontType, CharSet, EdgeSize, Italic) };
	}
};
class MV1 {
public:
	struct ani {
		int handle = 0;
		float per = 0.f;
		float time = 0.f;
		float alltime = 0.f;

		void reset() {
			this->per = 0.f;
			this->time = 0.f;
		}

		void update(const bool& loop, const float& speed) {
			this->time += 30.f / GetFPS()*speed;
			if (speed >= 0.f) {
				if (this->time >= this->alltime) {
					this->time = loop ? 0.f : this->alltime;
				}
			}
			else {
				if (this->time <= 0.f) {
					this->time = !loop ? 0.f : this->alltime;
				}
			}
		}
	};
private:
	int handle_;
	std::vector<ani> anime;
	MV1(int h) noexcept : handle_(h) {}
	static constexpr int invalid_handle = -1;
public:
	/*�R���X�g���N�^*/
	MV1(void) noexcept { handle_ = invalid_handle; }
	MV1(const MV1&) = delete;
	MV1(MV1&& o) noexcept : handle_(o.handle_) { o.handle_ = invalid_handle; }
	/*�I�y���[�^�[*/
	MV1& operator=(const MV1&) = delete;
	MV1& operator=(MV1&& o) noexcept {
		this->handle_ = o.handle_;
		o.handle_ = invalid_handle;
		return *this;
	}
	/*�f�X�g���N�^*/
	~MV1(void) noexcept {
		Dispose();
	}
	/**/
	int get(void) const noexcept { return this->handle_; }
	/*���f��*/
	bool SetPosition(const VECTOR_ref& p1) const noexcept { return MV1SetPosition(this->handle_, p1.get()) == TRUE; }
	VECTOR_ref GetPosition(void) const noexcept { return MV1GetPosition(this->handle_); }
	bool SetRotationZYAxis(const VECTOR_ref& zaxis, const VECTOR_ref& yaxis, float zrad) const noexcept { return MV1SetRotationZYAxis(this->handle_, zaxis.get(), yaxis.get(), zrad) == TRUE; }
	bool SetMatrix(const MATRIX_ref& mat) const noexcept { return MV1SetMatrix(this->handle_, mat.get()) == TRUE; }
	bool DrawModel(void) const noexcept { return MV1DrawModel(this->handle_) == TRUE; }
	bool SetOpacityRate(const float& p1) const noexcept { return MV1SetOpacityRate(this->handle_, p1) == TRUE; }
	bool SetScale(const VECTOR_ref& p1) const noexcept { return MV1SetScale(this->handle_, p1.get()) == TRUE; }
	/*�e�N�X�`��*/
	bool SetTextureGraphHandle(const int& p1, const GraphHandle& p2, bool trans) const noexcept { return MV1SetTextureGraphHandle(this->handle_, p1, p2.get(), trans ? TRUE : FALSE) == TRUE; }
	/*�t���[��*/
	VECTOR_ref frame(const int& p1) const noexcept { return MV1GetFramePosition(this->handle_, p1); }
	size_t frame_num(void) const noexcept { return MV1GetFrameNum(this->handle_); }
	size_t frame_parent(const int& p1) const noexcept { return MV1GetFrameParent(this->handle_, p1); }
	size_t frame_child_num(const int& p1) const noexcept { return MV1GetFrameChildNum(this->handle_, p1); }
	bool SetFrameLocalMatrix(const int& id, MATRIX_ref mat) const noexcept { return MV1SetFrameUserLocalMatrix(this->handle_, id, mat.get()) == TRUE; }

	MATRIX_ref GetFrameLocalMatrix(const int& id) const noexcept { return MV1GetFrameLocalMatrix(this->handle_, id); }
	MATRIX_ref GetFrameLocalWorldMatrix(const int& id) const noexcept { return MV1GetFrameLocalWorldMatrix(this->handle_, id); }
	MATRIX_ref GetMatrix(void) const noexcept { return MV1GetMatrix(this->handle_); }

	bool DrawFrame(const int& p1) const noexcept { return MV1DrawFrame(this->handle_, p1) == TRUE; }
	std::string frame_name(const size_t& p1) noexcept { return MV1GetFrameName(this->handle_, int(p1)); }

	void frame_reset(const int& p1) const noexcept { MV1ResetFrameUserLocalMatrix(this->handle_, p1); }
	/*�}�e���A��*/
	size_t material_num(void) const noexcept { return MV1GetMaterialNum(this->handle_); }
	void material_AlphaTestAll(bool Enable, int mode, int param) const noexcept {
		MV1SetMaterialDrawAlphaTestAll(this->handle_, Enable ? TRUE : FALSE, mode, param);
	}
	std::string material_name(const int& p1) noexcept { return MV1GetMaterialName(this->handle_, p1); }
	/*���b�V��*/
	size_t mesh_num(void) const noexcept { return MV1GetMeshNum(this->handle_); }
	VECTOR_ref mesh_maxpos(const int& p1) const noexcept { return MV1GetMeshMaxPosition(this->handle_, p1); }
	VECTOR_ref mesh_minpos(const int& p1) const noexcept { return MV1GetMeshMinPosition(this->handle_, p1); }
	bool DrawMesh(const int& p1) const noexcept { return MV1DrawMesh(this->handle_, p1) == TRUE; }
	/*�V�F�C�v*/
	int SearchShape(const char* str) const noexcept { return MV1SearchShape(this->handle_, str); }
	bool SetShapeRate(const int& p1, const float& p2) const noexcept { return MV1SetShapeRate(this->handle_, p1, p2) == TRUE; }
	/*�A�j���[�V����*/
	bool work_anime(void) {
		for (auto& a : this->anime) {
			MV1SetAttachAnimTime(this->handle_, a.handle, a.time);
			MV1SetAttachAnimBlendRate(this->handle_, a.handle, a.per);
		}
		return true;
	}
	auto& get_anime(const size_t& p1) {
		return this->anime[p1];
	}
	auto& get_anime(void) {
		return this->anime;
	}
	/*�������Z*/
	bool PhysicsResetState(void) const noexcept { return MV1PhysicsResetState(this->handle_) == TRUE; }
	bool PhysicsCalculation(const float& p1) const noexcept { return MV1PhysicsCalculation(this->handle_, p1) == TRUE; }
	/*�����蔻��*/
	bool SetupCollInfo(const int& x = 32, const int& y = 8, const int& z = 32, const int& frame = -1, const int& mesh = -1) const noexcept {
		return MV1SetupCollInfo(this->handle_, frame, x, y, z, mesh) == TRUE;
	}
	bool RefreshCollInfo(const int& frame = -1, const int& mesh = -1) const noexcept {
		return MV1RefreshCollInfo(this->handle_, frame, mesh) == TRUE;
	}
	const auto CollCheck_Line(const VECTOR_ref& start, const VECTOR_ref& end, const int& frame = -1, const int& mesh = -1) const noexcept {
		return MV1CollCheck_Line(this->handle_, frame, start.get(), end.get(), mesh);
	}
	const auto CollCheck_Sphere(const VECTOR_ref& startpos, const float& range, const int& frame = -1, const int& mesh = -1) const noexcept {
		return MV1CollCheck_Sphere(this->handle_, frame, startpos.get(), range, mesh);
	}

	const auto CollCheck_Capsule(const VECTOR_ref& startpos, const VECTOR_ref& endpos, const float& range, const int& frame = -1, const int& mesh = -1) const noexcept {
		return MV1CollCheck_Capsule(this->handle_, frame, startpos.get(), endpos.get(), range, mesh);
	}

	/*�ǂݍ���*/
	MV1 Duplicate(void) const noexcept { return DxLib::MV1DuplicateModel(this->handle_); }
	static void Load(std::basic_string_view<TCHAR> FileName, MV1* t, const bool& Async) noexcept {
		if (Async) {
			SetUseASyncLoadFlag(TRUE);
		}
		*t = DxLib::MV1LoadModelWithStrLen(FileName.data(), FileName.length());
		t->anime.clear();
		if (Async) {
			SetUseASyncLoadFlag(FALSE);
		}
		return;
	}
	static void LoadonAnime(std::basic_string_view<TCHAR> FileName, MV1* t, const int& mode = DX_LOADMODEL_PHYSICS_LOADCALC) noexcept {
		if (mode != DX_LOADMODEL_PHYSICS_LOADCALC) {
			MV1SetLoadModelUsePhysicsMode(mode);
		}

		*t = DxLib::MV1LoadModelWithStrLen(FileName.data(), FileName.length());

		t->anime.resize(MV1GetAnimNum(t->get()));
		if (t->anime.size() > 0) {
			for (int i = 0; i < int(t->anime.size()); i++) {
				t->anime[i].handle = MV1AttachAnim(t->get(), i);
				t->anime[i].reset();
				MV1SetAttachAnimBlendRate(t->get(), t->anime[i].handle, t->anime[i].per);
				t->anime[i].alltime = MV1GetAttachAnimTotalTime(t->get(), t->anime[i].handle);
			}
		}

		if (mode != DX_LOADMODEL_PHYSICS_LOADCALC) {
			MV1SetLoadModelUsePhysicsMode(DX_LOADMODEL_PHYSICS_LOADCALC);
		}
		return;
	}
	void DuplicateonAnime(MV1* temp) const noexcept {
		*temp = DxLib::MV1DuplicateModel(this->handle_);

		temp->anime.resize(MV1GetAnimNum(temp->get()));
		if (temp->anime.size() > 0) {
			for (int i = 0; i < int(temp->anime.size()); i++) {
				temp->anime[i].handle = MV1AttachAnim(temp->get(), i);
				temp->anime[i].reset();
				MV1SetAttachAnimBlendRate(temp->get(), temp->anime[i].handle, temp->anime[i].per);
				temp->anime[i].alltime = MV1GetAttachAnimTotalTime(temp->get(), temp->anime[i].handle);
			}
		}
		return;
	}
	/*�폜*/
	void Dispose(void) noexcept {
		if (this->handle_ != -1) {
			MV1DeleteModel(this->handle_);
			anime.clear();
			this->handle_ = -1;
		}
	}
};
//VR
#define BUTTON_TRIGGER vr::ButtonMaskFromId(vr::EVRButtonId::k_EButton_SteamVR_Trigger)
#define BUTTON_SIDE vr::ButtonMaskFromId(vr::EVRButtonId::k_EButton_Grip)
#define BUTTON_TOUCHPAD vr::ButtonMaskFromId(vr::EVRButtonId::k_EButton_SteamVR_Touchpad)
#define BUTTON_TOPBUTTON vr::ButtonMaskFromId(vr::EVRButtonId::k_EButton_ApplicationMenu)
#define BUTTON_TOPBUTTON_B vr::ButtonMaskFromId(vr::EVRButtonId::k_EButton_IndexController_B)
#define DEVICE_HMD vr::TrackedDeviceClass_HMD
#define DEVICE_CONTROLLER vr::TrackedDeviceClass_Controller
#define DEVICE_TRACKER vr::TrackedDeviceClass_GenericTracker
#define DEVICE_BASESTATION vr::TrackedDeviceClass_TrackingReference
//
using std::int8_t;
using std::size_t;
using std::uint16_t;
using std::uint8_t;

constexpr float M_GR = -9.8f;				  /*�d�͉����x*/
//�f�X�N�g�b�v�T�C�Y
inline const int32_t deskx = (int32_t)(GetSystemMetrics(SM_CXSCREEN));
inline const int32_t desky = (int32_t)(GetSystemMetrics(SM_CYSCREEN));
//�}�E�X����
#define in2_(mx, my, x1, y1, x2, y2) (mx >= x1 && mx <= x2 && my >= y1 && my <= y2)
#define in2_mouse(x1, y1, x2, y2) (in2_(mousex, mousey, x1, y1, x2, y2))
//���̑�
 //�p�x���烉�W�A����
template <typename T>
static float deg2rad(T p1) {
	return float(p1) * DX_PI_F / 180.f;
}
//���W�A������p�x��
template <typename T>
static float rad2deg(T p1) {
	return float(p1) * 180.f / DX_PI_F;
}
//�����񂩂琔�l�����o��
class getparams {
public:
	static std::string getright(const char* p1) {
		std::string tempname = p1;
		return tempname.substr(tempname.find('=') + 1);
	}
public:
	static const char* _char(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return getright(mstr).c_str();
	}
	static auto _str(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return getright(mstr);
	}
	static auto get_str(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return std::string(mstr);
	}
	static const long int _int(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return std::stoi(getright(mstr));
	}
	static const long int _long(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return std::stol(getright(mstr));
	}
	static const unsigned long int _ulong(int p2) {
		char mstr[64];
		FileRead_gets(mstr, 64, p2);
		return std::stoul(getright(mstr));
	}
	static const float _float(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return std::stof(getright(mstr));
	}
	static const bool _bool(int p1) {
		char mstr[64];
		FileRead_gets(mstr, 64, p1);
		return (getright(mstr).find("true") != std::string::npos);
	}
};
//�C�[�W���O
void easing_set(float* first, const float& aim, const float& ratio) {
	if (ratio == 0.f) {
		*first = aim;
	}
	else {
		if (aim != 0.f) {
			*first += (aim - *first) * (1.f - powf(ratio, 60.f / GetFPS()));
		}
		else {
			*first *= powf(ratio, 60.f / GetFPS());
		}
	}
};
void easing_set(VECTOR_ref* first, const VECTOR_ref& aim, const float& ratio) {
	if (ratio == 0.f) {
		*first = aim;
	}
	else {
		*first += (VECTOR_ref(aim) - *first) * (1.f - powf(ratio, 60.f / GetFPS()));
	}
};
//cosA���o��
float getcos_tri(const float& a, const float& b, const float& c) {
	if (b + c > a && c + a > b && a + b > c) {
		return std::clamp((b * b + c * c - a * a) / (2.f * b*c), -1.f, 1.f);
	}
	return 1.f;
}
//�N��
void createProcess(char* szCmd, DWORD flag, bool fWait) {
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si, 0, sizeof(STARTUPINFO));
	memset(&pi, 0, sizeof(PROCESS_INFORMATION));
	si.cb = sizeof(STARTUPINFO);
	CreateProcess(NULL, szCmd, NULL, NULL, FALSE, flag, NULL, NULL, &si, &pi);
	if (fWait) WaitForSingleObject(pi.hProcess, INFINITE);	//�I����҂�.
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
}
//���g�𑽏d�N��
void start_me(void) {
	char Path[MAX_PATH];
	// EXE�̂���t�H���_�̃p�X���擾
	::GetModuleFileName(NULL, Path, MAX_PATH);
	createProcess(Path, SW_HIDE, false);
}

//�G�t�F�N�g
class EffectS {
public:
	bool flug{ false };				 /**/
	size_t id = 0;					 /**/
	Effekseer3DPlayingHandle handle; /**/
	VECTOR_ref pos;					 /**/
	VECTOR_ref nor;					 /**/
	float scale = 1.f;				 /**/

	void set(VECTOR_ref pos_, VECTOR_ref nor_, float scale_ = 1.f) {
		this->flug = true;
		this->pos = pos_;
		this->nor = nor_;
		this->scale = scale_;
	}
	void put(const EffekseerEffectHandle& handle_) {
		if (this->flug) {
			if (this->handle.IsPlaying()) {
				this->handle.Stop();
			}
			this->handle = handle_.Play3D();
			this->handle.SetPos(this->pos);
			this->handle.SetRotation(atan2(this->nor.y(), std::hypot(this->nor.x(), this->nor.z())), atan2(-this->nor.x(), -this->nor.z()), 0);
			this->handle.SetScale(this->scale);
			this->flug = false;
		}
	}
	void set_loop(const EffekseerEffectHandle& handle_) {
		this->handle = handle_.Play3D();
	}
	void put_loop(VECTOR_ref pos_, VECTOR_ref nor_, float scale_ = 1.f) {
		this->flug = true;
		this->pos = pos_;
		this->nor = nor_;
		this->scale = scale_;
		this->handle.SetPos(this->pos);
		//this->handle.SetRotation(atan2(this->nor.y(), std::hypot(this->nor.x(), this->nor.z())), atan2(-this->nor.x(), -this->nor.z()), 0);
		this->handle.SetScale(this->scale);
	}
};
//
struct cam_info {
	VECTOR_ref campos, camvec, camup;	//�J����
	float fov = deg2rad(90);			//�J����
	float near_ = 0.1f, far_ = 10.f;	//�j�A�t�@�[

	void set_cam_pos(const VECTOR_ref& cam_pos, const VECTOR_ref& cam_vec, const VECTOR_ref& cam_up) {
		campos = cam_pos;
		camvec = cam_vec;
		camup = cam_up;	//�J����
	}

	void set_cam_info(const float& cam_fov_, const float& cam_near_, const float& cam_far_) {
		fov = cam_fov_;			//�J����
		near_ = cam_near_, far_ = cam_far_;	//�j�A�t�@�[
	}
};

class DXDraw {
public:
	int disp_x = deskx;
	int disp_y = desky;
	bool use_vr = true;

private:
	bool use_shadow = true;			/*�e�`��*/
	int shadow_near = 0;			/*�߉e*/
	int shadow_nearfar = 0;			/*�߉e*/
	int shadow_far = 0;				/*���e*/
	size_t shadow_size = 10;		/*�e�T�C�Y*/
	bool use_pixellighting = true;			     /**/
	bool use_vsync = false;				     /*��������*/
	float frate = 60.f;				     /*�t���[�����[�g*/
	//��
	struct Mirror_mod {
		VECTOR_ref WorldPos[4];	// ���̃��[���h���W
		COLOR_F AmbientColor;	// ���� Ambient Color
		COLOR_U8 DiffuseColor;	// ���� Diffuse Color
		int BlendParam[2] = { 0,0 };		// ���̃u�����h���[�h�ƃp�����[�^
		GraphHandle Handle;		// ���ɉf��f���̎擾�Ɏg�p����X�N���[��
		FLOAT4 ScreenPosW[4];	// ���ɉf��f���̎擾�Ɏg�p����N���[���̒��̋��̎l���̍��W( �������W )
		bool canlook = false;	//���������Ă��邩�ۂ�
	};
	std::vector<Mirror_mod> Mirror_obj;
	size_t MIRROR_POINTNUM = 64;	// ���̕`��Ɏg�p����ʂ̒��_������
	int MIRROR_NUM = 2;			// ���̐�
	std::vector <VERTEX3D> Vert;
	std::vector <unsigned short> Index;
	MATERIALPARAM Material;
	VECTOR_ref HUnitPos;
	VECTOR_ref VUnitPos[2];
	VECTOR_ref HPos;
	VECTOR_ref VPos[2];
	FLOAT4 HUnitUV;
	FLOAT4 VUnitUV[2];
	FLOAT4 HUV;
	FLOAT4 VUV[2];
	VECTOR_ref MirrorNormal;
	COLOR_U8 DiffuseColor;
	COLOR_U8 SpecularColor;
	int TextureW, TextureH;
	//VR
public:
	struct system_VR {
		int id = 0;
		VECTOR_ref pos = VGet(0, 0, 0);
		VECTOR_ref xvec = VGet(1, 0, 0);
		VECTOR_ref yvec = VGet(0, 1, 0);
		VECTOR_ref zvec = VGet(0, 0, 1);
		std::array<uint64_t, 2> on{ 0 };
		VECTOR_ref touch;
		char num = 0;
		vr::ETrackedDeviceClass type = vr::TrackedDeviceClass_Invalid;
		bool turn = false, now = false;
	};
private:
	vr::IVRSystem* m_pHMD = nullptr;
	vr::EVRInitError eError = vr::VRInitError_None;
	std::vector<system_VR> ctrl;							/*HMD,controller*/
	char deviceall = 0;
	VECTOR_ref pos;
	char hmd_num = -1;
	char hand1_num = -1;
	char hand2_num = -1;
public:
	std::vector<EffekseerEffectHandle> effHndle; /*�G�t�F�N�g���\�[�X*/
	std::array<GraphHandle, 3> outScreen;	//�X�N���[���o�b�t�@
	std::vector<char> tracker_num;

	size_t get_eff_size() { return effHndle.size(); }
	EffekseerEffectHandle& get_effHandle(int p1) noexcept { return effHndle[p1]; }
	const EffekseerEffectHandle& get_effHandle(int p1) const noexcept { return effHndle[p1]; }


	DXDraw(const char* title, const float& fps = 60.f, const bool& use_VR = false, const bool& use_SHADOW = true) {
		use_vr = use_VR;
		if (use_vr) {
			eError = vr::VRInitError_None;
			m_pHMD = vr::VR_Init(&eError, vr::VRApplication_Scene);
			if (eError != vr::VRInitError_None) {
				m_pHMD = nullptr;
				use_vr = false;
			}
		}

		this->use_shadow = use_SHADOW;
		this->shadow_size = 13;
		if (use_vr) {
			this->disp_x = 1080 * 2;
			this->disp_y = 1200 * 2;
		}
		else {
			this->disp_x = deskx;
			this->disp_y = desky;
		}

		this->frate = fps;
		SetOutApplicationLogValidFlag(false ? TRUE : FALSE);				/*log*/
		SetMainWindowText(title);											/*�^�C�g��*/
		ChangeWindowMode(TRUE);												/*���\��*/
		SetUseDirect3DVersion(DX_DIRECT3D_11);								/*directX ver*/
		SetGraphMode(this->disp_x, this->disp_y, 32);						/*�𑜓x*/
		SetUseDirectInputFlag(TRUE);										/**/
		SetDirectInputMouseMode(TRUE);										/**/
		SetWindowSizeChangeEnableFlag(FALSE, FALSE);						/*�E�C���h�E�T�C�Y���蓮�s�A�E�C���h�E�T�C�Y�ɍ��킹�Ċg������Ȃ��悤�ɂ���*/
		SetUsePixelLighting(use_pixellighting ? TRUE : FALSE);				/*�s�N�Z���V�F�[�_�̎g�p*/
		SetFullSceneAntiAliasingMode(4, 2);									/*�A���`�G�C���A�X*/
		SetEnableXAudioFlag(TRUE);											/**/
		Set3DSoundOneMetre(1.0f);											/**/
		SetWaitVSyncFlag(use_vsync ? TRUE : FALSE);							/*��������*/
		DxLib_Init();														/**/
		Effekseer_Init(8000);												/*Effekseer*/
		SetSysCommandOffFlag(TRUE);											/**/
		SetChangeScreenModeGraphicsSystemResetFlag(FALSE);					/*Effekseer*/
		Effekseer_SetGraphicsDeviceLostCallbackFunctions();					/*Effekseer*/
		SetAlwaysRunFlag(TRUE);												/*background*/
		SetUseZBuffer3D(TRUE);												/*zbufuse*/
		SetWriteZBuffer3D(TRUE);											/*zbufwrite*/
		MV1SetLoadModelPhysicsWorldGravity(-9.8f);							/*�d��*/
		SetWindowSize(deskx, desky);
		outScreen[0] = GraphHandle::Make(this->disp_x, this->disp_y);	/*����*/
		outScreen[1] = GraphHandle::Make(this->disp_x, this->disp_y);	/*�E��*/
		outScreen[2] = GraphHandle::Make(this->disp_x, this->disp_y);	/*TPS�p*/
		//VR�̃Z�b�g
		if (use_vr && m_pHMD) {
			tracker_num.clear();
			deviceall = 0;
			int i = 0;
			for (char k = 0; k < 8; k++) {
				auto old = deviceall;
				auto dev = m_pHMD->GetTrackedDeviceClass(k);
				if (dev == DEVICE_HMD) {
					hmd_num = deviceall;
					deviceall++;
				}
				else if (dev == DEVICE_CONTROLLER) {
					switch (i) {
					case 0:
						hand1_num = deviceall;
						i++;
						break;
					case 1:
						hand2_num = deviceall;
						i++;
						break;
					default:
						break;
					}
					deviceall++;
				}
				else if (dev == DEVICE_TRACKER) {
					tracker_num.emplace_back(deviceall);
					deviceall++;
				}
				else if (dev == DEVICE_BASESTATION) {
					deviceall++;
				}
				if (deviceall != old) {
					ctrl.resize(deviceall);
					ctrl.back().now = false;
					ctrl.back().id = old;
					ctrl.back().num = k;
					ctrl.back().type = dev;
					ctrl.back().turn = true;
				}
			}
		}

		//�G�t�F�N�g
		{
			std::string p;
			WIN32_FIND_DATA win32fdt;
			HANDLE hFind;
			hFind = FindFirstFile("data/effect/*", &win32fdt);
			if (hFind != INVALID_HANDLE_VALUE) {
				do {
					{
						p = win32fdt.cFileName;
						if (p.find(".efk") != std::string::npos) {
							effHndle.resize(effHndle.size() + 1);
							effHndle.back() = EffekseerEffectHandle::load("data/effect/" + p);
						}
					}
				} while (FindNextFile(hFind, &win32fdt));
			} //else{ return false; }
			FindClose(hFind);
		}
	}
	~DXDraw(void) {
		if (use_vr&&m_pHMD) {
			//vr::VR_Shutdown();
			m_pHMD = NULL;
		}
		Effkseer_End();
		DxLib_End();
	}
	template <typename T>
	bool Set_Light_Shadow(const VECTOR_ref& farsize, const VECTOR_ref& nearsize, const VECTOR_ref& Light_dir, T doing) {
		SetGlobalAmbientLight(GetColorF(0.12f, 0.11f, 0.10f, 0.0f));
		SetLightDirection(Light_dir.get());
		if (this->use_shadow) {
			shadow_near = MakeShadowMap(int(pow(2, this->shadow_size)), int(pow(2, this->shadow_size)));
			shadow_nearfar = MakeShadowMap(int(pow(2, this->shadow_size)), int(pow(2, this->shadow_size)));
			shadow_far = MakeShadowMap(int(pow(2, this->shadow_size)), int(pow(2, this->shadow_size)));
			SetShadowMapAdjustDepth(shadow_near, 0.0005f);
			SetShadowMapLightDirection(shadow_near, Light_dir.get());
			SetShadowMapAdjustDepth(shadow_nearfar, 0.0005f);
			SetShadowMapLightDirection(shadow_nearfar, Light_dir.get());
			SetShadowMapLightDirection(shadow_far, Light_dir.get());
			SetShadowMapDrawArea(shadow_far, nearsize.get(), farsize.get());
			ShadowMap_DrawSetup(shadow_far);
			doing();
			ShadowMap_DrawEnd();
		}
		return true;
	}
	bool Delete_Shadow() {
		if (this->use_shadow) {
			DeleteShadowMap(shadow_near);
			DeleteShadowMap(shadow_nearfar);
			DeleteShadowMap(shadow_far);
		}
		return true;
	}
	template <typename T>
	bool Update_far_Shadow(T doing) {
		if (this->use_shadow) {
			ShadowMap_DrawSetup(shadow_far);
			doing();
			ShadowMap_DrawEnd();
			return true;
		}
		return false;
	}
	template <typename T>
	bool Ready_Shadow(const VECTOR_ref& pos, T doing, const VECTOR_ref& nearsize, const VECTOR_ref& nearfarsize) {
		if (this->use_shadow) {
			SetShadowMapDrawArea(shadow_near, (nearsize*-1.f + pos).get(), (VECTOR_ref(nearsize) + pos).get());
			ShadowMap_DrawSetup(shadow_near);
			doing();
			ShadowMap_DrawEnd();

			SetShadowMapDrawArea(shadow_nearfar, (nearfarsize*-1.f + pos).get(), (VECTOR_ref(nearfarsize) + pos).get());
			ShadowMap_DrawSetup(shadow_nearfar);
			doing();
			ShadowMap_DrawEnd();
			return true;
		}
		return false;
	}
	template <typename T>
	bool Draw_by_Shadow(T doing) {
		if (this->use_shadow) {
			SetUseShadowMap(0, shadow_far);
			SetUseShadowMap(1, shadow_nearfar);
			SetUseShadowMap(2, shadow_near);
		}
		doing();
		if (this->use_shadow) {
			SetUseShadowMap(0, -1);
			SetUseShadowMap(1, -1);
			SetUseShadowMap(2, -1);
		}
		return true;
	}
	bool Screen_Flip(const LONGLONG& waits) {
		ScreenFlip();
		if (use_vr&&m_pHMD) {
			vr::TrackedDevicePose_t tmp;
			vr::VRCompositor()->WaitGetPoses(&tmp, 1, NULL, 1);
		}
		else if (!use_vsync) {
			while (GetNowHiPerformanceCount() - waits < 1000000.0f / frate) {}
		}
		return true;
	}
	static bool Capsule3D(const VECTOR_ref& p1, const VECTOR_ref& p2, const float& range, const unsigned int& color, const unsigned int& speccolor) {
		return DxLib::DrawCapsule3D(p1.get(), p2.get(), range, 8, color, speccolor, TRUE) == TRUE;
	}
	static bool Line2D(const int& p1x, const int& p1y, const int& p2x, const int& p2y, const unsigned int& color, const int& thickness = 1) {
		return DxLib::DrawLine(p1x, p1y, p2x, p2y, color, thickness) == TRUE;
	}

	//��
	VECTOR_ref Mirrorcampos, Mirrorcamtgt;
	auto& get_Mirror_obj() {
		return Mirror_obj;
	}
	auto& get_Mirror_obj(int i) {
		return Mirror_obj[std::min(i, int(Mirror_obj.size() - 1))];
	}
	// ���̏�����
	void Mirror_init(int p) {
		MIRROR_NUM = p;
		Mirror_obj.clear();
		for (int i = 0; i < MIRROR_NUM; i++) {
			Mirror_obj.resize(Mirror_obj.size() + 1);
			Mirror_obj.back().Handle = GraphHandle::Make(this->disp_x, this->disp_y, FALSE);	// ���ɉf��f���̎擾�Ɏg�p����X�N���[���̍쐬
		}
		Vert.resize(MIRROR_POINTNUM * MIRROR_POINTNUM);
		Index.resize((MIRROR_POINTNUM - 1) * (MIRROR_POINTNUM - 1) * 6);
	}
	void set_Mirror_obj(int i,
		VECTOR_ref pos1, VECTOR_ref pos2, VECTOR_ref pos3, VECTOR_ref pos4,
		COLOR_F ambcol,
		COLOR_U8 difcol,
		int param0, int param1
	) {
		auto& m = Mirror_obj[std::min(i, int(Mirror_obj.size() - 1))];
		m.WorldPos[0] = pos1;
		m.WorldPos[1] = pos2;
		m.WorldPos[2] = pos3;
		m.WorldPos[3] = pos4;
		m.AmbientColor = ambcol;
		m.DiffuseColor = difcol;
		m.BlendParam[0] = param0;
		m.BlendParam[1] = param1;
	}
	void Mirror_delete() {
		for (int i = 0; i < MIRROR_NUM; i++) {
			Mirror_obj[i].Handle.Dispose();
		}
		Mirror_obj.clear();
		Vert.clear();
		Index.clear();
	}
	// ���ɉf��f����`�悷�邽�߂̃J�����̐ݒ���s��.Mirrorcampos,Mirrorcamtgt�ɔ��f
	void Mirror_SetupCamera(Mirror_mod& MirrorNo, const VECTOR_ref& campos, const VECTOR_ref& camtgt, const VECTOR_ref& camup, const float& fov, const float& near_distance = 100.f, const float& far_distance = 1000.f) {
		auto& id = MirrorNo;
		// ���̖ʂ̖@�����Z�o
		MirrorNormal = ((id.WorldPos[1] - id.WorldPos[0]).cross(id.WorldPos[2] - id.WorldPos[0])).Norm();
		// ���̖ʂ���J�����̍��W�܂ł̍ŒZ�����A���̖ʂ���J�����̒����_�܂ł̍ŒZ�������Z�o
		float EyeLength = Plane_Point_MinLength(id.WorldPos[0].get(), MirrorNormal.get(), campos.get());
		float TargetLength = Plane_Point_MinLength(id.WorldPos[0].get(), MirrorNormal.get(), camtgt.get());
		// ���ɉf��f����`�悷��ۂɎg�p����J�����̍��W�ƃJ�����̒����_���Z�o
		Mirrorcampos = VECTOR_ref(campos) + MirrorNormal * (-EyeLength * 2.0f);
		Mirrorcamtgt = VECTOR_ref(camtgt) + MirrorNormal * (-TargetLength * 2.0f);
		// ���ɉf��f���̒��ł̋��̎l���̍��W���Z�o( �������W )
		id.Handle.SetDraw_Screen(Mirrorcampos, Mirrorcamtgt, VGet(0, 1.f, 0.f), fov, near_distance, far_distance);
		for (int i = 0; i < 4; i++) {
			id.ScreenPosW[i] = ConvWorldPosToScreenPosPlusW(id.WorldPos[i].get());
		}
		// ���ɉf��f���̒��ł̋��̎l���̍��W���Z�o( �������W )
		id.Handle.SetDraw_Screen(campos, camtgt, camup, fov, near_distance, far_distance);
		id.canlook = true;
		for (int z = 0; z < 4; z++) {
			if (id.canlook) {
				float p = ConvWorldPosToScreenPos(id.WorldPos[z].get()).z;
				if (p < 0.0f || p > 1.1f) {
					id.canlook = false;
				}
			}
		}
		//�~���[�I�t
		id.canlook = false;

	}
	// ���̕`��
	void Mirror_Render(void) {
		for (auto& obj : Mirror_obj) {
			if (obj.canlook) {
				// ���̕`��Ɏg�p����}�e���A���̃Z�b�g�A�b�v
				Material.Ambient = obj.AmbientColor;
				Material.Diffuse = GetColorF(0.0f, 0.0f, 0.0f, 0.0f);
				Material.Emissive = GetColorF(0.0f, 0.0f, 0.0f, 0.0f);
				Material.Specular = GetColorF(0.0f, 0.0f, 0.0f, 0.0f);
				Material.Power = 1.0f;
				SetMaterialParam(Material);
				// ���̖ʂ̖@�����Z�o
				MirrorNormal = ((obj.WorldPos[1] - obj.WorldPos[0]).cross(obj.WorldPos[2] - obj.WorldPos[0])).Norm();
				// ���ɉf��f�����������񂾉摜�̃e�N�X�`���̃T�C�Y���擾
				GetGraphTextureSize(obj.Handle.get(), &TextureW, &TextureH);
				// ���̕`��Ɏg�p���钸�_�̃Z�b�g�A�b�v
				{
					VUnitPos[0] = (obj.WorldPos[2] - obj.WorldPos[0])*(1.0f / (MIRROR_POINTNUM - 1));
					VUnitPos[1] = (obj.WorldPos[3] - obj.WorldPos[1])*(1.0f / (MIRROR_POINTNUM - 1));
					VUnitUV[0] = F4Scale(F4Sub(obj.ScreenPosW[2], obj.ScreenPosW[0]), 1.0f / (MIRROR_POINTNUM - 1));
					VUnitUV[1] = F4Scale(F4Sub(obj.ScreenPosW[3], obj.ScreenPosW[1]), 1.0f / (MIRROR_POINTNUM - 1));
					DiffuseColor = obj.DiffuseColor;
					SpecularColor = GetColorU8(0, 0, 0, 0);
					VPos[0] = obj.WorldPos[0];
					VPos[1] = obj.WorldPos[1];
					VUV[0] = obj.ScreenPosW[0];
					VUV[1] = obj.ScreenPosW[1];
					int k = 0;
					for (auto& v : Vert) {
						if (k%MIRROR_POINTNUM == 0) {
							HUnitPos = (VPos[1] - VPos[0])*(1.0f / (MIRROR_POINTNUM - 1));
							HPos = VPos[0];
							HUnitUV = F4Scale(F4Sub(VUV[1], VUV[0]), 1.0f / (MIRROR_POINTNUM - 1));
							HUV = VUV[0];
						}
						{
							v.pos = HPos.get();
							v.norm = MirrorNormal.get();
							v.dif = DiffuseColor;
							v.spc = SpecularColor;
							v.u = HUV.x / (HUV.w * TextureW);
							v.v = HUV.y / (HUV.w * TextureH);
							v.su = 0.0f;
							v.sv = 0.0f;
							HUV = F4Add(HUV, HUnitUV);
							HPos += HUnitPos;
						}
						if (k%MIRROR_POINTNUM == 0) {
							VUV[0] = F4Add(VUV[0], VUnitUV[0]);
							VUV[1] = F4Add(VUV[1], VUnitUV[1]);
							VPos[0] += VUnitPos[0];
							VPos[1] += VUnitPos[1];
						}
						k++;
					}
				}
				// ���̕`��Ɏg�p���钸�_�C���f�b�N�X���Z�b�g�A�b�v
				{
					int k = 0;
					for (int i = 0; i < MIRROR_POINTNUM - 1; i++) {
						for (int j = 0; j < MIRROR_POINTNUM - 1; j++) {
							Index[k++] = unsigned short((i + 0) * MIRROR_POINTNUM + j + 0);
							Index[k++] = unsigned short((i + 0) * MIRROR_POINTNUM + j + 1);
							Index[k++] = unsigned short((i + 1) * MIRROR_POINTNUM + j + 0);
							Index[k++] = unsigned short((i + 1) * MIRROR_POINTNUM + j + 1);
							Index[k++] = unsigned short((i + 1) * MIRROR_POINTNUM + j + 0);
							Index[k++] = unsigned short((i + 0) * MIRROR_POINTNUM + j + 1);
						}
					}
				}
				// ����`��
				SetDrawMode(DX_DRAWMODE_BILINEAR);
				SetDrawBlendMode(obj.BlendParam[0], obj.BlendParam[1]);
				DrawPolygonIndexed3D(&Vert[0], int(Vert.size()), &Index[0], int(Index.size() / 3), obj.Handle.get(), FALSE);
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 255);
				SetDrawMode(DX_DRAWMODE_NEAREST);
			}
		}
	}

	//VR
	const auto& get_hmd_num(void) { return hmd_num; }
	const auto& get_hand1_num(void) { return hand1_num; }
	const auto& get_hand2_num(void) { return hand2_num; }
	auto* get_device(void) { return &ctrl; }
	auto* get_device_hmd(void) {
		if (hmd_num >= 0) {
			return &ctrl[std::max<char>(hmd_num, 0)];
		}
		else {
			return (system_VR*)nullptr;
		}
	}
	auto* get_device_hand1(void) {
		if (hand1_num >= 0) {
			return &ctrl[std::max<char>(hand1_num, 0)];
		}
		else {
			return (system_VR*)nullptr;
		}
	}
	auto* get_device_hand2(void) {
		if (hand2_num >= 0) {
			return &ctrl[std::max<char>(hand2_num, 0)];
		}
		else {
			return (system_VR*)nullptr;
		}
	}
	/**/
	void Move_Player(void) {
		if (use_vr&&m_pHMD) {
			vr::TrackedDevicePose_t tmp;
			vr::VRControllerState_t night;
			for (auto& c : ctrl) {
				if (c.type == DEVICE_HMD) {
					m_pHMD->GetDeviceToAbsoluteTrackingPose(vr::TrackingUniverseStanding, 0.0f, &tmp, 1);
					c.on[0] = 0;
					c.on[1] = 0;
					c.touch = VGet(0, 0, 0);
					c.now = tmp.bPoseIsValid;
					c.pos = VGet(tmp.mDeviceToAbsoluteTracking.m[0][3], tmp.mDeviceToAbsoluteTracking.m[1][3], -tmp.mDeviceToAbsoluteTracking.m[2][3]);
					c.xvec = VGet(-tmp.mDeviceToAbsoluteTracking.m[0][0], -tmp.mDeviceToAbsoluteTracking.m[1][0], tmp.mDeviceToAbsoluteTracking.m[2][0]);
					c.yvec = VGet(tmp.mDeviceToAbsoluteTracking.m[0][1], tmp.mDeviceToAbsoluteTracking.m[1][1], -tmp.mDeviceToAbsoluteTracking.m[2][1]);
					c.zvec = VGet(tmp.mDeviceToAbsoluteTracking.m[0][2], tmp.mDeviceToAbsoluteTracking.m[1][2], -tmp.mDeviceToAbsoluteTracking.m[2][2]);
				}
				else if (c.type == DEVICE_CONTROLLER || c.type == DEVICE_BASESTATION || c.type == DEVICE_TRACKER) {
					m_pHMD->GetControllerStateWithPose(vr::TrackingUniverseStanding, c.num, &night, sizeof(night), &tmp);
					c.on[0] = night.ulButtonPressed;
					c.on[1] = night.ulButtonTouched;
					c.touch = VGet(night.rAxis[0].x, night.rAxis[0].y, 0);
					c.now = tmp.bPoseIsValid;
					c.pos = VGet(tmp.mDeviceToAbsoluteTracking.m[0][3], tmp.mDeviceToAbsoluteTracking.m[1][3], -tmp.mDeviceToAbsoluteTracking.m[2][3]);
					c.xvec = VGet(-tmp.mDeviceToAbsoluteTracking.m[0][0], -tmp.mDeviceToAbsoluteTracking.m[1][0], tmp.mDeviceToAbsoluteTracking.m[2][0]);
					c.yvec = VGet(tmp.mDeviceToAbsoluteTracking.m[0][1], tmp.mDeviceToAbsoluteTracking.m[1][1], -tmp.mDeviceToAbsoluteTracking.m[2][1]);
					c.zvec = VGet(tmp.mDeviceToAbsoluteTracking.m[0][2], tmp.mDeviceToAbsoluteTracking.m[1][2], -tmp.mDeviceToAbsoluteTracking.m[2][2]);
				}
			}
		}
		else {
			for (auto& c : ctrl) {
				c.on[0] = 0;
				c.on[1] = 0;
				c.touch = VGet(0, 0, 0);
				c.pos = VGet(0, 0, 0);
				c.xvec = VGet(1, 0, 0);
				c.yvec = VGet(0, 1, 0);
				c.zvec = VGet(0, 0, 1);
			}
		}
	}
	/**/
	inline VECTOR_ref SetEyePositionVR(const char& eye_type) {
		if (use_vr&&m_pHMD) {
			const vr::HmdMatrix34_t tmpmat = vr::VRSystem()->GetEyeToHeadTransform((vr::EVREye)eye_type);
			return ctrl[hmd_num].pos + ctrl[hmd_num].xvec*(tmpmat.m[0][3]) + ctrl[hmd_num].yvec*(tmpmat.m[1][3]) + ctrl[hmd_num].zvec*(-tmpmat.m[2][3]);
		}
		else {
			return VGet(0, 0, 0);
		}
	}
	/**/
	inline void GetDevicePositionVR(const char& handle_, VECTOR_ref* pos_, MATRIX_ref*mat) {
		if (use_vr && handle_ != -1) {
			*pos_ = ctrl[handle_].pos;
			*mat = MATRIX_ref::Axis1(ctrl[handle_].xvec*-1.f, ctrl[handle_].yvec, ctrl[handle_].zvec*-1.f);
		}
		else {
			*pos_ = VGet(0, 0, 0);
			*mat = MATRIX_ref::Axis1(VGet(1, 0, 0), VGet(0, 1, 0), VGet(0, 0, 1));
		}
	}
	/**/
	inline VECTOR_ref GetEyePosition_minVR(const char& eye_type) {
		if (use_vr&&m_pHMD) {
			const vr::HmdMatrix34_t tmpmat = vr::VRSystem()->GetEyeToHeadTransform((vr::EVREye)eye_type);
			return (ctrl[hmd_num].xvec*-1.f*(tmpmat.m[0][3])) + (ctrl[hmd_num].yvec*(tmpmat.m[1][3])) + (ctrl[hmd_num].zvec*-1.f*(tmpmat.m[2][3]));
		}
		else {
			return VGet(0, 0, 0);
		}
	}
	/**/
	inline void PutEye(ID3D11Texture2D* texte, const char& i) {
		if (use_vr) {
			vr::Texture_t tex = { (void*)texte, vr::ETextureType::TextureType_DirectX,vr::EColorSpace::ColorSpace_Auto };
			vr::VRCompositor()->Submit((vr::EVREye)i, &tex, NULL, vr::Submit_Default);
		}
	}
	/**/
	template <typename T2>
	void draw_VR(T2 draw_doing, const cam_info& cams) {
		if (this->use_vr) {
			for (char i = 0; i < 2; i++) {
				outScreen[i].SetDraw_Screen(VECTOR_ref(cams.campos) + this->GetEyePosition_minVR(i), VECTOR_ref(cams.camvec) + this->GetEyePosition_minVR(i), cams.camup, cams.fov, cams.near_, cams.far_);

				draw_doing();

				GraphHandle::SetDraw_Screen((int)DX_SCREEN_BACK);
				{
					SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 255);
					outScreen[i].DrawGraph(0, 0, false);
					this->PutEye((ID3D11Texture2D*)GetUseDirect3D11BackBufferTexture2D(), i);
				}
			}
		}
		else {
			outScreen[0].SetDraw_Screen(cams.campos, cams.camvec, cams.camup, cams.fov, cams.near_, cams.far_);
			draw_doing();
		}
		GraphHandle::SetDraw_Screen((int)DX_SCREEN_BACK);
		{
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 255);
			outScreen[0].DrawExtendGraph(0, 0, deskx, desky, true);
		}
	}
	/**/
	inline void Haptic(const char&id_, unsigned short times) {
		if (id_ != -1) {
			if (use_vr&&m_pHMD) {
				m_pHMD->TriggerHapticPulse(ctrl[id_].id, 2, times);
			}
		}
	}
};

typedef std::pair<int, VECTOR_ref> frames;
class switchs {
public:
	bool first;
	uint8_t second;

	switchs() {
		first = false;
		second = 0;
	};

	void ready(bool on) {
		first = on;
		second = 0;
	}

	void get_in(bool key) {
		second = std::clamp<uint8_t>(second + 1, 0, (key ? 2 : 0));
		if (push()) {
			first ^= 1;
		}
	}

	const bool on() {
		return first;
	}

	const bool push() {
		return second == 1;
	}

};

class HostPassEffect {
private:
	GraphHandle FarScreen_;		//�`��X�N���[��
	GraphHandle NearFarScreen_;	//�`��X�N���[��
	GraphHandle NearScreen_;	//�`��X�N���[��
	GraphHandle GaussScreen_;	//�`��X�N���[��
	GraphHandle BufScreen;		//�`��X�N���[��
	GraphHandle BufScreen_;		//�`��X�N���[��
	GraphHandle SkyScreen;		//��`��
	GraphHandle MAIN_Screen;	//�`��X�N���[��

	int EXTEND = 4;
	bool dof_flag = true;
	bool bloom_flag = true;
	int disp_x = deskx;
	int disp_y = desky;
public:
	int input_low = 25;
	int input_high = 255;
	float gamma = 1.8f;
	int output_low = 0;
	int output_high = 255;

	HostPassEffect(const bool& dof_, const bool& bloom_, const int& xd, const int& yd) {
		disp_x = xd;
		disp_y = yd;
		//DoF�p
		dof_flag = dof_;
		SkyScreen = GraphHandle::Make(disp_x, disp_y, false);						//��`��
		FarScreen_ = GraphHandle::Make(disp_x, disp_y, true);						//�`��X�N���[��
		NearFarScreen_ = GraphHandle::Make(disp_x, disp_y, true);					//�`��X�N���[��
		NearScreen_ = GraphHandle::Make(disp_x, disp_y, true);						//�`��X�N���[��
		//�u���[���p
		bloom_flag = bloom_;
		GaussScreen_ = GraphHandle::Make(disp_x / EXTEND, disp_y / EXTEND, true);	//�`��X�N���[��
		BufScreen_ = GraphHandle::Make(disp_x, disp_y, true);						//�`��X�N���[��
		//�ŏI�`��p
		BufScreen = GraphHandle::Make(disp_x, disp_y, true);						//�`��X�N���[��
		MAIN_Screen = GraphHandle::Make(disp_x, disp_y, true);						//�`��X�N���[��
	}
	~HostPassEffect() {
	}
private:
	//�u���[���G�t�F�N�g
	void buf_bloom(const int& level = 255) {
		if (bloom_flag) {
			GraphFilterBlt(BufScreen.get(), BufScreen_.get(), DX_GRAPH_FILTER_TWO_COLOR, 250, GetColor(0, 0, 0), 255, GetColor(128, 128, 128), 255);
			GraphFilterBlt(BufScreen_.get(), GaussScreen_.get(), DX_GRAPH_FILTER_DOWN_SCALE, EXTEND);
			GraphFilter(GaussScreen_.get(), DX_GRAPH_FILTER_GAUSS, 16, 1000);
		}
		BufScreen.SetDraw_Screen(false);
		if (bloom_flag) {
			SetDrawMode(DX_DRAWMODE_BILINEAR);
			SetDrawBlendMode(DX_BLENDMODE_ADD, level);
			GaussScreen_.DrawExtendGraph(0, 0, disp_x, disp_y, true);
			GaussScreen_.DrawExtendGraph(0, 0, disp_x, disp_y, true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 255);
		}
	}
	//���x���␳
	void buf_levelcorrect() {
		if (true) {
			GraphFilterBlt(BufScreen.get(), BufScreen_.get(), DX_GRAPH_FILTER_LEVEL, input_low, input_high, int(gamma * 100), output_low, output_high);
		}
		BufScreen.SetDraw_Screen(false);
		if (true) {
			BufScreen_.DrawExtendGraph(0, 0, disp_x, disp_y, true);
		}
	}

	//��ʑ̐[�x�`��
	template <typename T1, typename T2>
	void near_dof(T1 sky_doing, T2 doing, cam_info& cams, bool update_effekseer = true) {
		if (dof_flag) {
			//��
			SkyScreen.SetDraw_Screen(cams.campos - cams.camvec, VGet(0, 0, 0), cams.camup, cams.fov, 1000.0f, 5000.0f);
			{
				sky_doing();
			}
			//������
			FarScreen_.SetDraw_Screen(cams.campos, cams.camvec, cams.camup, cams.fov, cams.far_, 1000000.f);
			{
				SkyScreen.DrawGraph(0, 0, FALSE);
				doing();
			}
			//����
			NearFarScreen_.SetDraw_Screen(cams.campos, cams.camvec, cams.camup, cams.fov, cams.near_, cams.far_);
			{
				Effekseer_Sync3DSetting();
				GraphFilter(FarScreen_.get(), DX_GRAPH_FILTER_GAUSS, 16, 200);
				FarScreen_.DrawGraph(0, 0, false);
				if (update_effekseer) {
					UpdateEffekseer3D();
				}
				doing();
				DrawEffekseer3D();
			}
			//����
			NearScreen_.SetDraw_Screen(cams.campos, cams.camvec, cams.camup, cams.fov, 0.1f, 0.1f + cams.near_);
			{
				NearFarScreen_.DrawGraph(0, 0, false);
				doing();
			}
		}
	}
	//���ɉ��������`��
	template <typename T1, typename T2>
	void near_nomal(T1 sky_doing, T2 doing, cam_info& cams, bool update_effekseer = true) {
		//��
		SkyScreen.SetDraw_Screen(cams.campos - cams.camvec, VGet(0, 0, 0), cams.camup, cams.fov, 1000.0f, 5000.0f);
		{
			sky_doing();
		}
		NearScreen_.SetDraw_Screen(cams.campos, cams.camvec, cams.camup, cams.fov, 0.1f, cams.far_);
		{
			Effekseer_Sync3DSetting();
			SkyScreen.DrawGraph(0, 0, FALSE);
			if (update_effekseer) {
				UpdateEffekseer3D();
			}
			doing();
			DrawEffekseer3D();
		}
	}
public:
	template <typename T1, typename T2>
	void BUF_draw(T1 sky_doing, T2 doing, cam_info& cams, bool update_effekseer = true) {
		//near�ɕ`��
		if (dof_flag) {
			near_dof(sky_doing, doing, cams, update_effekseer);
		}
		else {
			near_nomal(sky_doing, doing, cams, update_effekseer);
		}
		//���ʕ`��
		BufScreen.SetDraw_Screen();
		{
			NearScreen_.DrawGraph(0, 0, false);
		}
	}
	//
	void MAIN_draw() {
		//buf�ɕ`��
		buf_bloom(255);//�u���[��
		buf_levelcorrect();
		//���ʕ`��
		MAIN_Screen.SetDraw_Screen();
		{
			BufScreen.DrawGraph(0, 0, false);
		}
	}
	//
	GraphHandle& get_main() {
		return MAIN_Screen;
	}
};
//����
class DeBuG {
private:
	int frate;
	std::vector<std::array<float, 6 + 2>> deb;
	LONGLONG waypoint = 0;
	std::array<float, 6> waydeb{ 0.f };
	size_t seldeb;
	FontHandle font;
	const int fontsize = 12;
public:
	DeBuG(const float& fps_rate = 60.f) {
		frate = int(fps_rate);
		font = FontHandle::Create(fontsize, DX_FONTTYPE_EDGE);
		deb.resize(frate);
	}
	void put_way(void) {
		waypoint = GetNowHiPerformanceCount();
		seldeb = 0;
	}
	void end_way(void) {
		if (seldeb < waydeb.size()) {
			waydeb[seldeb++] = (float)(GetNowHiPerformanceCount() - waypoint) / 1000.0f;
		}
	}
	void debug(int xpos, int ypos, float time) {
		int wide = 180;
		deb[0][0] = time;
		deb[0][1] = 1000.f / GetFPS();
		for (size_t j = deb.size() - 1; j >= 1; --j) {
			deb[j][0] = deb[j - 1][0];
			deb[j][1] = deb[j - 1][1];
		}
		for (size_t i = 0; i < waydeb.size(); ++i) {
			if (seldeb - 1 <= i) {
				waydeb[i] = waydeb[seldeb - 1];
			}
			deb[0][i + 2] = waydeb[i];
			for (size_t j = deb.size() - 1; j >= 1; --j) {
				deb[j][i + 2] = deb[j - 1][i + 2];
			}
		}

		float xs = float(wide) / float(frate);
		float ys = float(int(waydeb.size() + 1) * fontsize) / float(frate);

		DrawBox(xpos, ypos, xpos + wide, ypos + int(100.f*ys), GetColor(0, 0, 0), TRUE);
		DrawBox(xpos, ypos, xpos + wide, ypos + int(100.f*ys), GetColor(255, 0, 0), FALSE);

		for (size_t j = 0; j < deb.size() - 1; ++j) {
			size_t jt = j + 1;
			for (size_t i = 0; i < waydeb.size(); ++i) {
				DXDraw::Line2D(xpos + int(float(j) * xs), ypos + int(100.f*ys) - int(deb[j][i + 2] * 5.f), xpos + int(float(jt) * xs), ypos + int(100.f*ys) - int(deb[jt][i + 2] * 5.f), GetColor(50, 128 + 127 * int(i) / 6, 50));
			}
			DXDraw::Line2D(xpos + int(float(j) * xs), ypos + int(100.f*ys) - int(deb[j][0] * 5.f), xpos + int(float(jt) * xs), ypos + int(100.f*ys) - int(deb[jt][0] * 5.f), GetColor(255, 255, 0));
			DXDraw::Line2D(xpos + int(float(j) * xs), ypos + int(100.f*ys) - int(deb[j][1] * 5.f), xpos + int(float(jt) * xs), ypos + int(100.f*ys) - int(deb[jt][1] * 5.f), GetColor(128, 255, 128));
		}
		const auto c_ffffff = GetColor(255, 255, 255);
		DXDraw::Line2D(xpos, ypos + int(50.f*ys), xpos + wide, ypos + int(50.f*ys), GetColor(0, 255, 0));

		font.DrawStringFormat(xpos, ypos, c_ffffff, "%05.2ffps ( %.2fms)", GetFPS(), time);

		font.DrawStringFormat(xpos, ypos + fontsize, c_ffffff, "%d(%.2fms)", 0, waydeb[0]);
		for (size_t j = 1; j < waydeb.size(); ++j) {
			font.DrawStringFormat(xpos, ypos + int(j + 1) * fontsize, c_ffffff, "%d(%.2fms)", j, waydeb[j] - waydeb[j - 1u]);
		}
	}
};